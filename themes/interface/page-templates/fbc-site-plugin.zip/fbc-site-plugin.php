<?php

/*
Plugin Name: FBC Site Plugin
Plugin URI: http://douglaswebdesigns.com/prison-services-plugin
Description: This plugin customizes the WordPress Admin Dashboard.
Version: 1.0
Author: Paul Douglas
Author URI: http://douglaswebdesigns.com
License: GPLv2
*/

?>

<?php 

// Rename Posts to News in Menu
function dwd_change_post_menu_label() {
    global $menu;
    global $submenu;
    $menu[5][0] = 'News';
    $submenu['edit.php'][5][0] = 'FBC Page/Post Items';
    $submenu['edit.php'][10][0] = 'Add FBC Page/Post Item';
}
add_action( 'admin_menu', 'dwd_change_post_menu_label' );

// Edit submenus
function dwd_change_post_object_label() {
    global $wp_post_types;
    $labels = &$wp_post_types['post']->labels;
    $labels->name = 'FBC Page/Post Item';
    $labels->singular_name = 'FBC Page/Post Item';
    $labels->add_new = 'Add FBC Page/Post Item';
    $labels->add_new_item = 'Add FBC Page/Post Item';
    $labels->edit_item = 'Edit FBC Page/Post Item';
    $labels->new_item = 'FBC Page/Post Item';
    $labels->view_item = 'View FBC Page/Post Item';
    $labels->search_items = 'Search FBC Page/Post Items';
    $labels->not_found = 'No FBC Page/Post Items found';
    $labels->not_found_in_trash = 'No FBC Page/Post Items found in Trash';
}
add_action( 'admin_menu', 'dwd_change_post_object_label' );

// Remove Comments menu item for all but Administrators
function dwd_remove_comments_menu_item() {
    $user = wp_get_current_user();
    if ( ! $user->has_cap( 'manage_options' ) ) {
        remove_menu_page( 'edit-comments.php' );
    }
}
add_action( 'admin_menu', 'dwd_remove_comments_menu_item' );

// Move Pages above Media
function dwd_change_menu_order( $menu_order ) {
    return array(
        'index.php',
        'edit.php',
        'edit.php?post_type=page',
        'upload.php',
    );
}
add_filter( 'custom_menu_order', '__return_true' );
add_filter( 'menu_order', 'dwd_change_menu_order' );

?>